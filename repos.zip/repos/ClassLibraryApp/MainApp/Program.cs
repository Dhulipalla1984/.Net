﻿// See https://aka.ms/new-console-template for more information

using System;

namespace PrinciplesApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Invoice FInvoice = new FinalInvoice();
            double FInvoices = (int)FInvoice.GetInvoiceDiscount(10000);
            Console.WriteLine(FInvoices);
            //Console.WriteLine("test");
        }
    }
}
