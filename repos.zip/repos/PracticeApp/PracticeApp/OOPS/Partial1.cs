﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeApp
{
    public partial class Partial
    {
        public void Display() {
            Console.WriteLine("Author name is :" + AuthorName);
            Console.WriteLine("Author age is :" + AuthorAge);
        }
    }
}
