﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeApp
{
    class Base
    {
        public Base()
        {
            Console.WriteLine("Base Constructor Called");
        }
        public virtual void Method()
        {
            Console.WriteLine("Base method");
        }
    }

    class Derived : Base
    {
        public Derived()
        {
            Console.WriteLine("Derived Constructor Called");

        }
        public override void Method()
        {
            Console.WriteLine("Derived method");
        }
    }

    class Derived2 : Derived
    {
        public Derived2()
        {
            Console.WriteLine("Derived2 Constructor Called");

        }
        public void Method()
        {
            Console.WriteLine("Derived2 method");
        }
    }

    
}
