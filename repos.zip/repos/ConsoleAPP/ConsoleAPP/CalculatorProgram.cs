﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAPP
{
    internal class CalculatorProgram
    {
        int _Number1, _Number2, _Result;

        public int Number1 { get { return _Number1; } set { _Number1 = value; } }
        public int Number2 { get { return _Number2; } set { _Number2 = value; } }
            public int Result { get { return _Result; } set { _Result = value; } }

    }
}
